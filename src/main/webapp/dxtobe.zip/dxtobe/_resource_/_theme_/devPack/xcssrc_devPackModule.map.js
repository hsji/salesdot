(function()
{
	return function()
	{
		nexacro._setCSSMaps(
		{

		},
		{
            "includeStatusMap" : true,
            			"applyMarkupValidation" : true
		}
		);
		var imgcache = nexacro._getImageCacheMaps();

	};
}
)();
