var NchartCustomer = '투비소프트 CNS';
var NchartProject = '테스트프로젝트';
var NchartDomain = '127.0.0.1,localhost';
var NchartLicense = '6lUeNpBf1Mz+dxPnrQklolzOXlEVe2vdBOkYWX2NmEHYjz7aCyVFnpSLBvwGLuYb9mDt0rwHDCQK+F/kepL8bQ==';
