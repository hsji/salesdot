﻿var pForm = nexacro.Form.prototype;
pForm.gfnWriteExcel = function() {

	var ws = {};
	var wInfo= [];
	var mo = 0.75;
	
	var range = {	s: {c:0, r:0 }, 
					e: {c:9, r:34 }
				};
				
	wInfo[0] = { wpx : parseInt(29*mo) };
	wInfo[1] = { wpx : parseInt(89*mo) };
	wInfo[2] = { wpx : parseInt(45*mo) };
	wInfo[3] = { wpx : parseInt(124*mo) };
	wInfo[4] = { wpx : parseInt(91*mo) };
	wInfo[5] = { wpx : parseInt(89*mo) };
	wInfo[6] = { wpx : parseInt(31*mo) };
	wInfo[7] = { wpx : parseInt(12*mo) };
	wInfo[8] = { wpx : parseInt(89*mo) };
	wInfo[9] = { wpx : parseInt(124*mo) };
	
	var hInfo = [];
	hInfo[0] = { hpx : parseInt(24*mo) };
	hInfo[1] = { hpx : parseInt(24*mo) };
	hInfo[2] = { hpx : parseInt(24*mo) };
	hInfo[3] = { hpx : parseInt(24*mo) };
	hInfo[4] = { hpx : parseInt(24*mo) };
	// 부서
	hInfo[5] = { hpx : parseInt(30*mo) };
	// 지급 및 공제내역
	hInfo[6] = { hpx : parseInt(24*mo) };
	hInfo[7] = { hpx : parseInt(24*mo) };
	// 지급 내용
	hInfo[8] = { hpx : parseInt(30*mo) };
	hInfo[9] = { hpx : parseInt(30*mo) };
	hInfo[10] = { hpx : parseInt(30*mo) };
	hInfo[11] = { hpx : parseInt(30*mo) };
	hInfo[12] = { hpx : parseInt(30*mo) };
	hInfo[13] = { hpx : parseInt(30*mo) };
	hInfo[14] = { hpx : parseInt(30*mo) };
	hInfo[15] = { hpx : parseInt(30*mo) };
	hInfo[16] = { hpx : parseInt(30*mo) };
	hInfo[17] = { hpx : parseInt(30*mo) };
	hInfo[18] = { hpx : parseInt(30*mo) };
	hInfo[19] = { hpx : parseInt(30*mo) };
	hInfo[20] = { hpx : parseInt(30*mo) };
	hInfo[21] = { hpx : parseInt(30*mo) };
	// 종합
	hInfo[22] = { hpx : parseInt(24*mo) };
	hInfo[23] = { hpx : parseInt(24*mo) };
	// 종합내역
	hInfo[24] = { hpx : parseInt(30*mo) };
	hInfo[25] = { hpx : parseInt(30*mo) };
	hInfo[26] = { hpx : parseInt(30*mo) };	
	// 
	hInfo[27] = { hpx : parseInt(30*mo) };	
	hInfo[28] = { hpx : parseInt(19*mo) };	
	hInfo[29] = { hpx : parseInt(19*mo) };	
	
	// 
	hInfo[30] = { hpx : parseInt(19*mo) };	
	hInfo[31] = { hpx : parseInt(19*mo) };	
	// 날짜
	hInfo[31] = { hpx : parseInt(19*mo) };	

	hInfo[32] = { hpx : parseInt(19*mo) };	
	hInfo[33] = { hpx : parseInt(19*mo) };	
	
	hInfo[34] = { hpx : parseInt(30*mo) };	
	
	var mInfo = [];
	mInfo.push({s: {c: 1, r: 1}, e: {c: 9, r: 2}});
	// title
	var cell_ref = XLSX.utils.encode_cell(	{	c : 1,
												r : 1});
	var fs = 11;
	var oStyle = {};
	oStyle.alignment = {};
	oStyle.alignment.horizontal = "center";
	oStyle.alignment.vertical = "center";	
	
	oStyle.fill = {};
	oStyle.fill.patternType = "solid";
	oStyle.fill.fgColor = {};
	oStyle.fill.fgColor.rgb = "ffffff";
	
	oStyle.font = {};
	oStyle.font.color = {};		
	oStyle.font.name = "Malgun Gothic";
	oStyle.font.sz = parseInt(fs * 72 / 96);
	oStyle.font.bold = true;
	
	oStyle.border = {};
	oStyle.border.left = { style: null, color: { rgb: "ffffff" } };
	oStyle.border.right = oStyle.border.bottom = oStyle.border.top = oStyle.border.left;
	ws[cell_ref] = 	{ 	v : "TEST 입니다." ,
						t : "s" ,
						s : oStyle,
					};	
			

	ws['!cols'] = wInfo;
	ws['!rows'] = hInfo;
	ws['!merges'] = mInfo;
		
	ws['!ref'] = XLSX.utils.encode_range(range);
		
	var Workbook = {
						SheetNames: [],
						Sheets: {}
					};	
	Workbook.SheetNames[0] = "Sheet0";
	Sheets["Sheet0"] = ws;
	var extentionname = "xlsx";
	var xlsfilename = "test";
	var wbout = XLSX.write(Workbook, {bookType:extentionname, bookSST:false, cellNF:true, cellStyles:true, type: 'binary', compression : true });
	FilUtil.save(wbout, extentionname, xlsfilename);
	
};